<?php

namespace App\Http\Model\Product;

use Illuminate\Database\Eloquent\Model;

class CartModel extends Model
{
    protected $guarded = [];
}
