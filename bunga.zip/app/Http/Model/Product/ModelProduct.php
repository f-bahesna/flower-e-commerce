<?php

namespace App\Http\Model\Product;


class ModelProduct extends Authenticatable
{
    public function GetAllProducts()
    {
        
    }
}
