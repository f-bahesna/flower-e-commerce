<?php

namespace App\Http\Controllers\Jenis;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class JenisController extends Controller
{
    public function index()
    {
        echo "Menu Jenis";
    }
}
