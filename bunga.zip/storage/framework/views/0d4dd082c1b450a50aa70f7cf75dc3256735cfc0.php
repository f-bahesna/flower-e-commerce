<script>
    $(function(){
      $(document).ready(function(){
        $("input[type=number]").on("change",function(){
            console.log($(this).val());
         })
      })
    });
 </script><?php /**PATH D:\Coding\Portfolio\bunga\resources\views/cart/cart-utilities.blade.php ENDPATH**/ ?>