<?php $__env->startSection('title','Halaman Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5 mb-5">
    <div class="row justify-content-center ">
        <div class="col-md-5">
            <!-- Material form register -->
            <div class="card card-register d-flex">

                <h5 class="card-header bg-success white-text text-center py-4">
                    <strong><?php echo e(__('Register')); ?></strong>
                </h5>

                <!--Card content-->
                <div class="card-body px-lg-5 pt-0 mt-3">

                    <!-- Form -->
                    <form class="text-center form-register"  method="POST" style="color: #757575;" action="<?php echo e(route('user.register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="col">
                                <!-- name -->
                                <div class="md-form">
                                    <input placeholder="Nama" id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                </div>
                            </div>
                            <div class="col">
                                <!-- Nomor HP -->
                                <div class="md-form">
                                    <input placeholder="Nomor HP" id="nomor_telephone" type="number" class="form-control <?php if ($errors->has('nomor_telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nomor_telephone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="nomor_telephone" value="<?php echo e(old('nomor_telephone')); ?>" required autofocus>
                                </div>

                                <?php if ($errors->has('nomor_telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nomor_telephone'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                            </div>
                        </div>

                        <!-- E-mail -->
                        <div class="md-form mt-0 mt-3">
                            <input placeholder="email" id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>

                        <!-- Password -->
                        <div class="md-form mt-3">
                            <input placeholder="password" id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">
                            <small id="materialRegisterFormPasswordHelpBlock" class="form-text text-muted mb-4">
                                Minimal 8 kata dan 1 angka
                            </small>
                        </div>

                        <!-- Password Confirmation -->
                        <div class="md-form">
                            <input placeholder="ulangi password" id="password_confirmation" type="password" class="form-control" name="password_confirmation" required>
                            <small id="materialRegisterFormPasswordHelpBlock" class="form-text text-muted mb-4">
                                Ulangi password anda
                            </small>
                        </div>

                        <!-- Sign up button -->
                        <button class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0" type="submit" id="btn-register"><?php echo e(__('Register')); ?></button>

                        <!-- Social register -->
                        <p>or sign up with:</p>

                        <a type="button" class="btn-floating btn-fb btn-sm">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a type="button" class="btn-floating btn-tw btn-sm">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a type="button" class="btn-floating btn-li btn-sm">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a type="button" class="btn-floating btn-git btn-sm">
                            <i class="fab fa-github"></i>
                        </a>

                        <hr>

                        <!-- Terms of service -->
                        <p>Setelah daftar anda setuju dengan
                            <a href="" target="_blank">aturan aturan yang berlaku</a>
                    </form>
                    <!-- Form -->

                </div>

            </div>
            <!-- Material form register -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.appUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Portfolio\bunga\resources\views/auth/register.blade.php ENDPATH**/ ?>