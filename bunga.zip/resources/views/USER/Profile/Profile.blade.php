@extends('layouts.admin.appAdmin')
@section('title','Dashboard')

@section('content')
  
    <h4>Profile</h4>
@endsection